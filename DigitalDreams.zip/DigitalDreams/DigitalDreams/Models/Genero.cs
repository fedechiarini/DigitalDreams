﻿namespace DigitalDreams.Models
{
    public enum Genero
    {
        TERROR,RPG,CARRERA,SHOOTER,PUZZLE,AVENTURA
    }
}
