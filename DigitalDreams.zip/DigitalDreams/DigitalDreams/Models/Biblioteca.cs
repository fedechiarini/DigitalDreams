﻿using System.Collections.Generic;

namespace DigitalDreams.Models
{
    public class Biblioteca
    {
        public int ID { get; set; } 
        public List<Juego> JuegoList { get; set; } 
       
    }
}
