﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace DigitalDreams.Models
{
    public class Carrito
    {
        public int Id { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "La fecha de compra es obligatoria")]
        [Display(Name = "Fecha De Compra")]
        public DateTime FechaDeCompra { get; set; }
        [Display(Name = "ID del Juego Deseado ")]
        public int? JuegoId { get; set; }
       

        public Juego Juego { get; set; }
        [Display(Name = "ID del usuario que realiza la compra")]
        public int? UsuarioId { get; set; }

        public Usuario Usuario { get; set; }
    }
}
