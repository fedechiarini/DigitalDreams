﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace DigitalDreams.Models
{
    public class Juego
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del juego  es obligatorio")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "el precio  es obligatorio")]
        [Range(1, 10000, ErrorMessage = "El valor debe ser mayor que 1 y menor a 10000")]
        // [DataType(DataType.,ErrorMessage ="Debe ingresar un valor numerico")]
        public double Precio { get; set; }

        [EnumDataType(typeof(Genero))]
        [Display(Name = "Género")]
        public Genero Genero { get; set; }





    }
}