﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace DigitalDreams.Models
{
    public class Usuario
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required(ErrorMessage = "El nombre de usuario es obligatorio")]
        public string Nombre { get; set; }
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "La clave es obligatorio")]

        public string Contraseña { get; set; }
        /* public Biblioteca Biblioteca { get; set; }
         public Carrito Carrito { get; set; }*/





    }
}