﻿using DigitalDreams.Models;
using Microsoft.EntityFrameworkCore;

namespace DigitalDreams.Contexto
{
    public class UsuarioContext : DbContext
    {
        public UsuarioContext(DbContextOptions<UsuarioContext> options) : base(options)
        {
        }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Juego> Juegos { get; set; }
        public DbSet<Carrito> Carritos { get; set; }


    }
}