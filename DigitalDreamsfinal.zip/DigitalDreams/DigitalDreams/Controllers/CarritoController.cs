﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DigitalDreams.Contexto;
using DigitalDreams.Models;

namespace DigitalDreams.Controllers
{
    public class CarritoController : Controller
    {
        private readonly UsuarioContext _context;

        public CarritoController(UsuarioContext context)
        {
            _context = context;
        }

        // GET: Carrito
        public async Task<IActionResult> Index()
        {
            var usuarioContext = _context.Carritos.Include(c => c.Juego).Include(c => c.Usuario);
            return View(await usuarioContext.ToListAsync());
        }

        // GET: Carrito/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carrito = await _context.Carritos
                .Include(c => c.Juego)
                .Include(c => c.Usuario)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (carrito == null)
            {
                return NotFound();
            }

            return View(carrito);
        }

        // GET: Carrito/Create
        public IActionResult Create()
        {
            ViewData["JuegoId"] = new SelectList(_context.Juegos, "Id", "Nombre");
            ViewData["UsuarioId"] = new SelectList(_context.Usuarios, "Id", "Nombre");
            return View();
        }

        // POST: Carrito/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,FechaDeCompra,JuegoId,UsuarioId")] Carrito carrito)
        {
            if (ModelState.IsValid)
            {
                bool carritoExistente = _context.Carritos.FirstOrDefault(c =>
            c.UsuarioId == carrito.UsuarioId && c.JuegoId == carrito.JuegoId) != null;

                if (carritoExistente)
                {
                    ModelState.AddModelError("", "Ya existe un carrito con el mismo usuario y juego.");
                    ViewData["JuegoId"] = new SelectList(_context.Juegos, "Id", "Nombre", carrito.JuegoId);
                    ViewData["UsuarioId"] = new SelectList(_context.Usuarios, "Id", "Nombre", carrito.UsuarioId);

                    return View(carrito);
                }
                else
                {
                    carrito.FechaDeCompra = DateTime.Now;
                    _context.Add(carrito);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }
            ViewData["JuegoId"] = new SelectList(_context.Juegos, "Id", "Nombre", carrito.JuegoId);
            ViewData["UsuarioId"] = new SelectList(_context.Usuarios, "Id", "Nombre", carrito.UsuarioId);
            return View(carrito);
        }

        // GET: Carrito/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carrito = await _context.Carritos.FindAsync(id);
            if (carrito == null)
            {
                return NotFound();
            }
            ViewData["JuegoId"] = new SelectList(_context.Juegos, "Id", "Nombre", carrito.JuegoId);
            ViewData["UsuarioId"] = new SelectList(_context.Usuarios, "Id", "Contraseña", carrito.UsuarioId);
            return View(carrito);
        }

        // POST: Carrito/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,FechaDeCompra,JuegoId,UsuarioId")] Carrito carrito)
        {
            if (id != carrito.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carrito);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarritoExists(carrito.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["JuegoId"] = new SelectList(_context.Juegos, "Id", "Nombre", carrito.JuegoId);
            ViewData["UsuarioId"] = new SelectList(_context.Usuarios, "Id", "Contraseña", carrito.UsuarioId);
            return View(carrito);
        }

        // GET: Carrito/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carrito = await _context.Carritos
                .Include(c => c.Juego)
                .Include(c => c.Usuario)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (carrito == null)
            {
                return NotFound();
            }

            return View(carrito);
        }

        // POST: Carrito/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var carrito = await _context.Carritos.FindAsync(id);
            _context.Carritos.Remove(carrito);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarritoExists(int id)
        {
            return _context.Carritos.Any(e => e.Id == id);
        }
    }
}
